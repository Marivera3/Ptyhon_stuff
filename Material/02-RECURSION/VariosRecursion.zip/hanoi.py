def Hanoi(n,Fuente,Auxiliar,Destino): 
    if(n == 1): 
        print ("disco en "+Fuente+" se mueve a "+Destino) 
    else: 
        Hanoi(n-1,Fuente,Destino,Auxiliar) 
        print ("disco en "+Fuente+" se mueve a "+Destino) 
        Hanoi(n-1,Auxiliar,Fuente,Destino)

# Main
print("solución para n = 2")
Hanoi(2,"A","B","C")
print()
print("solución para n = 3")
Hanoi(3,"A","B","C")
print()
print("solución para n = 4")
Hanoi(4,"A","B","C")
print("sol para n = 64")
# Hanoi(64,"A","B","C")
