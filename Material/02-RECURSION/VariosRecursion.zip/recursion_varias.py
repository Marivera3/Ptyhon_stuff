def sumaDigitos(num):
   if (num // 10 == 0):
      return num
   return (num % 10) + sumaDigitos(num // 10)

def fibonacci(n):
   if (n == 0 or n == 1):
      return 1
   return fibonacci(n-1) + fibonacci(n-2)

def invertirString(s):
   if (s == "" or len(s) == 1):
      return s
   return s[(len(s)-1)] + invertirString(s[0:len(s)-1])

def esPalindromo(s):
   s = s.replace(" ", "")
   if (len(s) == 1):
      return True
   if (s[0] != s[len(s)-1]):
      return False
   return esPalindromo(s[1:len(s)-1])

def misterio(lista, i, j, x):
   if (lista[(i+j)//2] == x):
      return True

   if (i == j):
      return False
   else:
      return misterio (lista, i, (i+j)//2, x) or misterio (lista, (i+j)//2+1, j, x)

print("\n>>> Suma de Dígitos-----------------------------")
print("102 = " ,sumaDigitos(102))
print("9 = " ,sumaDigitos(9))
print("249017 = " ,sumaDigitos(249017))

print("\n>>> Fibonacci-----------------------------")
print("1 = " , fibonacci(1))
print("12 = " , fibonacci(12))
print("0 = " , fibonacci(0))

print("\n>>> Invertir String-----------------------------")
print("\"\" = " , invertirString(''))
print("\"Hola Mundo\" = " , invertirString("Hola mundo"))

print("\n>>> Es Palíndromo?-----------------------------");
frases = ["oso", "araña","se van sus naves", "una frase cualquiera"]

for i in range(0,len(frases)):
   if (esPalindromo(frases[i])):
      print("\"" , frases[i] , "\" es palíndromo! :)")
   else:
      print("\"" , frases[i] , "\" NO es palíndromo")

print("\n>>> misterio?-----------------------------");
numeros = [14,3,100,23,45,6,1,12,76,88,192,0,60]

print("números = [14,3,100,23,45,6,1,12,76,88,192,0,60]")

print("len(numeros) = ",len(numeros))

print("i=0, j=3, x=45 -->" , misterio(numeros, 0, 3, 45))
print("i=2, j=5, x=45 -->" , misterio(numeros, 2, 5, 45))
print("i=0, j=9, x=60 -->" , misterio(numeros, 0, 9, 60))
print("i=0, j=12, x=60 -->" , misterio(numeros, 0, 12, 60))
print("i=6, j=10, x=100 -->" , misterio(numeros, 6, 10, 100))


