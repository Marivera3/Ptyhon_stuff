def anagramas(pal,prefijo=""):
    if len(pal) <= 1:
        print(prefijo+pal)
    else:
        for i in range(len(pal)):
            antes = pal[0:i]
            despues = pal[i+1:]
            anagramas(antes+despues,prefijo+pal[i])

anagramas("hola")
