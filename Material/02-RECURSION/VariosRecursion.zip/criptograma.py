﻿""" Programa para descrifrar el código secreto en un mensaje encriptado.
    El mensaje consiste de tres palabras: s1  s2  s3.
    Debemos asignar un número distinto a cada letra del mensaje.
    Clave: Sabemos que la asignación válida de números es aquella que
    hace correcta la ecuación: s1 + s2 = s3.
"""
def cript(s1,s2,s3,letras,aux = ""):
    '''
    s1, s2, s3 son las palabras del mensaje secreto.
    letras contiene todas las letras sin repetir del mensaje.
    aux es una variable auxiliar donde pondremos los números
        que asignaremos a cada letra. 
    Caso base de término de una rama recursiva: cuando las
        asignaciones de números (string aux) a letras (string letras) 
        tienen el mismo largo.
    '''
    # Caso Base
    if len (aux) == len(letras):
        for i in range(len(letras)):
            # Reemplaza letras por numeros
            s1 = s1.replace(letras[i],aux[i]) 
            s2 = s2.replace(letras[i],aux[i])
            s3 = s3.replace(letras[i],aux[i]) 

        #Condicion para verificar si aux es válido o no
        if int(s1)+ int(s2) == int(s3):
            print("logramos descifrar el mensaje")
            print("el código secreto es: ")
            return aux

        else:
            return  # retorna None. Tambien podríamos retornar False
    '''
    Llamada recursiva: solo puedo poner de 0 a 9 y no se debe repetir
    Ojo que en este momento a se va agrandando --> va agregando el numero
    '''
    for i in range (10):
        if not str(i) in aux:
            resultado = cript(s1,s2,s3,letras,aux+str(i))

            if not (resultado == None):
                return resultado
   

s1 =  "SEND"
s2 =  "MORE"
s3 = "MONEY"

letras = ""   # definimos un string vacío
# Ahora ponemos en el string letras todas las letras (sin repetir)
# que vienen en el mensaje. En este caso, debemos hacer:
# letras = " S E N D M O R Y "
for car in s1+s2+s3:
    if not car in letras:
        letras += car
        
# llamamos ahora a la función recursiva
secreto = cript(s1,s2,s3,letras)
# Imprimimos el resultado 
print(secreto)

