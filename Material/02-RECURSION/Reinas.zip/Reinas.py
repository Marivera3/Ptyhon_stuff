﻿def valido(tablero):
    """ validación filas """
    for fila in range(len(tablero)):
        cont = 0
        for col in range(len(tablero)):
            if (tablero[fila][col]):
                cont += 1
        if cont > 1: return False
    """ validación columnas """
    for col in range(len(tablero)):
        cont = 0
        for fila in range(len(tablero)):
            if (tablero[fila][col]):
                cont += 1
        if cont > 1: return False
    """ validación diagonales \\ """
    for j in range(len(tablero)-1):
        cont = 0
        for i in range(len(tablero)-j):
            if (tablero[i][i+j]):
                cont += 1
        if cont > 1: return False
    for i in range(1,len(tablero)-1):
        cont = 0
        for j in range(len(tablero)-i):
            if (tablero[i+j][j]):
                cont += 1
        if cont > 1: return False
    """ validación diagonales // """
    for j in range(len(tablero)-1):
        cont = 0
        col= len(tablero)-1-j
        for i in range(len(tablero)-j):
            if (tablero[i][col-i]):
                cont += 1
        if cont > 1: return False
    for i in range(1,len(tablero)-1):
        cont = 0
        for j in range(len(tablero)-i):
            col= len(tablero)-1-j
            if (tablero[i+j][col]):
                cont += 1
        if cont > 1: return False              
    return True

def ubicarReina(tablero,col):
    """ Caso Base """
    if col == len(tablero):
        return True   # listo!
    """ Recursión BT """
    for i in range(len(tablero)):
        tablero[i][col] = True
        if valido(tablero):
            if ubicarReina(tablero,col+1):
                return True
        tablero[i][col] = False
    return False

# main
tablero = [[False, False, False,False],
           [False, False, False,False],
           [False, False, False,False],
           [False, False, False,False]]
for i in range(len(tablero)):
    print (tablero[i])
ubicarReina(tablero,0)
print()
for i in range(len(tablero)):
    print (tablero[i])


