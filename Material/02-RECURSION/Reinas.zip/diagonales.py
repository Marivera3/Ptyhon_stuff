def diagonales(tablero):
    print()
    print("diagonales \\", end=" ")
    for j in range(len(tablero)-1):
        print()
        for i in range(len(tablero)-j): 
            print("(",i,i+j,")", end=" ")
    for i in range(1,len(tablero)-1):
        print()
        for j in range(len(tablero)-i):
            print("(",i+j,j,")", end=" ")
    print()
    print()
    print("diagonales /", end=" ")
    for j in range(len(tablero)-1):
        print()
        col= len(tablero)-1-j
        for i in range(len(tablero)-j):
            print("(",i,col-i,")", end=" ")
    for i in range(1,len(tablero)-1):
        print()
        for j in range(len(tablero)-i):
            col= len(tablero)-1-j
            print("(",i+j,col,")", end=" ")
#            
# main
tablero = [[False, False, False,False],
           [False, False, False,False],
           [False, False, False,False],
           [False, False, False,False]]
print("El Tablero: ")
for i in range(len(tablero)):
    print (tablero[i])
#
diagonales(tablero)

