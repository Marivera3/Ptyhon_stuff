﻿""" Se lee un laberinto desde un archivo (matriz nfilas X ncols),
    y encuentra el camino de salida usando BackTracking.
    El laberinto de entrada está en un archivo .csv (desde Excel)
    y cada casilla está separado por un ";" """
class LaberPyX:
    marca = "*"  # camino que recorremos
    pared = "X"  # pared del laberinto
    libre = "."  # espacio libre del laberinto
  
    def __init__(self,f_ini,c_ini,f_end,c_end):
        # Atributos de una instancia de laberinto:
        self.f_ini = f_ini  # fila de inicio
        self.c_ini = c_ini  # columna de inicio
        self.f_end = f_end  # fila de salida 
        self.c_end = c_end  # columna de salida
        self.lab = []      #lista-matriz vacía para guardar el laberinto 
        self.generar_lab() #transforma archivo .csv en lista-matriz
        self.nfilas = len(self.lab)  # número de filas en matriz lab
        self.ncols = len(self.lab[0]) #número de columnas en matriz lab

    def generar_lab(self):
        arch1 = input("ingresa nombre del archivo .csv : ")
        entrada = open(arch1)
        for linea in entrada:
            linea = linea.strip("\n")
            lista = linea.split(";")
            self.lab.append(lista)
        entrada.close()

    def __str__(self):
        m = ""
        for fila in range(self.nfilas):
            for col in range(self.ncols):
                m += self.lab[fila][col] + " "
            m += "\n"
        return m
    
    def valida(self,f,c):
        """ retorna True si la celda es válida y False en caso contrario """
        # revisa si la celda esta fuera del laberinto
        if (f < 0 or f >= self.nfilas) or (c < 0 or c >= self.ncols):
            return False
        # revisa si la celda ya fue visitada o es pared
        if (self.lab[f][c] == self.marca) or (self.lab[f][c] == self.pared):
            return False
        # if (lab[f][c] == libre):
        return True

    def recorre(self,f="ini",c="ini"):
        """ método recursivo con BT que regresa cuando termina un camino
	    retorna True si la celda (f,c) es la salida
	    y False en caso contrario """
        # definición parámetros iniciales (comienzo del laberinto)
        if f == "ini":
            f = self.f_ini
        if c == "ini":
            c = self.c_ini
        listo = False  # aún no se encuentra la salida
        self.lab[f][c] = self.marca  # marcamos la celda como visitada
        """ 
	Caso Base: condición de término exitoso de la búsqueda recursiva 
	"""
        if (f == self.f_end) and (c == self.c_end):
            return True
        """ 
	Si no es el Caso Base, seguimos con algoritmo recursivo BT
	"""
        """ (1) intentamos para arriba """
        if not listo and self.valida(f-1, c):
            listo = self.recorre(f-1, c)
        """ (2) si no está listo, intentamos para la derecha """
        if not listo and self.valida(f, c+1):
            listo = self.recorre(f, c+1)
        """ (3) si no está listo, intentamos para abajo """
        if not listo and self.valida(f+1, c):
            listo = self.recorre(f+1, c)
        """ (4) si no está listo, intentamos para izquierda """
        if not listo and self.valida(f, c-1):
            listo = self.recorre(f, c-1)
        # si llegamos al final de este camino y no tiene salida,
        # debemos desmarcarlo y retornar
        if not listo:
            self.lab[f][c] = self.libre
        # se acabó esta bifurcación del árbol de solución 
	# y retornamos el resultado sea positivo o negativo 
        return listo

        
""" programa principal """
x0 = 1   # fila de inicio
y0 = 0   # columna de inicio
x1 = 11  # fila de salida 
y1 = 20  # columna de salida

Lab1 = LaberPyX(x0,y0,x1,y1)
print()
print("Laberinto propuesto:\n")
print(Lab1)

if Lab1.recorre():
    print("Laberinto Resuelto!!!!")
else: print ("No tiene solución!!!")
print()
print(Lab1)




        
