""" Leer un archivo ".csv" y escribir otro archivo
    en formato ".txt" cambiando los ";" por " "
    y los "." por "_"  """
arch1 = input("ingresa nombre del archivo .csv : ")
entrada = open(arch1)
arch2 = input("ingresa nombre del nuevo archivo .txt : ")
salida = open(arch2,"w")
for linea in entrada:
    nueva = linea.replace(";"," ")
    nueva = nueva.replace(".","_")
    print(nueva,file=salida)
    print(nueva,end="")
entrada.close()
salida.close()
